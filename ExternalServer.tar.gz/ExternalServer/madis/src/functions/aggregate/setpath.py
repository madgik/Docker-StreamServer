import sys, os
curmodulepath = os.path.dirname( os.path.abspath(__file__) )
sys.path.append(os.path.abspath(os.path.join(curmodulepath,'..','..')))